package com.AprendeaPrograma;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AprendeaProgramarApplication {

	public static void main(String[] args) {
		SpringApplication.run(AprendeaProgramarApplication.class, args);
	}

}
