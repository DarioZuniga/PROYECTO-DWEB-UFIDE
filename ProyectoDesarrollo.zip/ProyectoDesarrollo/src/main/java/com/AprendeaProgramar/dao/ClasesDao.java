package com.AprendeaProgramar.dao;

import com.AprendeaProgramar.domain.Clases;
import org.springframework.data.repository.CrudRepository;

public interface ClasesDao extends CrudRepository<Clases, Long> {

}
