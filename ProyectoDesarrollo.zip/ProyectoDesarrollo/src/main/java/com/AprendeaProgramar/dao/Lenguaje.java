package com.AprendeaProgramar.dao;


import org.springframework.data.repository.CrudRepository;

public interface Lenguaje extends CrudRepository<Lenguaje, Long>{

}
