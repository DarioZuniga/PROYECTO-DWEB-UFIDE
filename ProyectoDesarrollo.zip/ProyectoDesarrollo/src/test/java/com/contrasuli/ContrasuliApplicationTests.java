package com.contrasuli;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContrasuliApplicationTests {

	@Test
	void contextLoads() {
	}

}
